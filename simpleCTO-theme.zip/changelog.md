* [095d7f8](https://github.com/TryGhost/Casper/commit/095d7f8) 2.10.5 - Rish
* [56d1ff2](https://github.com/TryGhost/Casper/commit/56d1ff2) Better contrast for selected text inside `pre code` blocks - Mark Vasilkov
* [dc74e24](https://github.com/TryGhost/Casper/commit/dc74e24) 🔗 Updated docs link to be version-less - Aileen Nowak
